//accepted

// #include<iostream>
// using namespace std;
// int main(){
//     int t;
//     cin>>t;
//    while(t>0){
//     int n,count=0;
//     cin>>n;
//     char s[n];
//        cin>>s;
//        for(int j=0;j<n;j++){
//         if(s[j]=='p'&&s[j+1]=='i'&&s[j+2]=='e')count++;
//         else if(s[j]=='m'&&s[j+1]=='a'&&s[j+2]=='p'){count++;j+=2;}
//        }
//        cout<<count<<endl;
//        t--;
//    }
// }


//time limit exceeding

// // #include <iostream>
// // #include<string.h>
// // #include<algorithm>
// // #include<string>
// // using namespace std;
// // int main() {
// //   int t, n, moves = 0;
// //   cin >> t;
// //   for (int i = 0; i < t; i++) {
// //     cin >> n;
// //     char s[n];
// //     cin >> s;
// //     for (int k = 0; k <= n - 3; k++) {
// //       if (s[k] == 'm') {
// //         if (s[k + 1] == 'a') {
// //           if (s[k + 2] == 'p') {
// //             if (s[k + 3] == 'i'&&s[k + 4] == 'e') {
// //               // s.erase(k+2, 1);
// //                 for (int r = k + 2; r < n - 1; r++)
// //                   s[r] = s[r + 1];
// //                 n--;
// //                 moves++;
// //             } else {
// //               for (int r = k + 1; r < n - 1; r++)
// //                 s[r] = s[r + 1];
// //               n--;
// //               moves++;
// //             }
// //           }
// //         }
// //       } else if (s[k] == 'p') {
// //         if (s[k + 1] == 'i') {
// //           if (s[k + 2] == 'e') {
// //             for (int r = k + 1; r < n - 1; r++)
// //               s[r] = s[r + 1];
// //             n--;
// //             moves++;
// //           }
// //         }
// //       }
// //     }

// //     cout << moves << endl;
// //     moves = 0;
// //   }
// // }

// #include <bits/stdc++.h>
// using namespace std;

// int main(){
//     ios::sync_with_stdio(false);
//     cin.tie(NULL);
//     cout.tie(NULL);

//     int t ;
//     cin>>t;
//     while(t--){
//         int cnt = 0, len, i = 0;
//         cin >> len;
//         vector<char> str(len);
//         for (int j = 0; j < len; j++){
//             cin >> str[j];
//             if(j>=4){
//                 if ((str[j - 4] == 'm' && str[j - 3] == 'a' && str[j-2] == 'p') && (str[j - 2] == 'p' && str[j - 1] == 'i' && str[j] == 'e'))cnt++;
//                 else if (str[j - 2] == 'm' && str[j - 1] == 'a' && str[j] == 'p') cnt++;
//                 else if (str[j - 2] == 'p' && str[j - 1] == 'i' && str[j] == 'e')cnt++;
//             }
//             else if (j >= 2){
//                 if (str[j - 2] == 'm' && str[j - 1] == 'a' && str[j] == 'p')cnt++;
//                 if (str[j - 2] == 'p' && str[j - 1] == 'i' && str[j] == 'e')cnt++;
//             }
//         }
//         cout << cnt << endl;
//     }
//     return 0;
// }
